<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header("Location: login.php");
    exit();
}

include "db.php";
include "PHPMailer/PHPMailer.php";
include "PHPMailer/SMTP.php";
include "PHPMailer/Exception.php";

$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : '';

if ($startDate && !$endDate) {
    $endDate = date('Y-m-d'); // Set endDate to today's date if not provided
}

// Handle verification status change
if (isset($_POST['verify_vendor'])) {
    $vendor_id = $_POST['vendor_id'];
    $new_status = $_POST['verification_status'];

    // Generate a unique verification code if verifying the vendor
    $v_code = bin2hex(random_bytes(16));

    // Update the verification status in the database
    $update_query = "UPDATE `vendors` SET `verification_status` = '$new_status', `verification_code` = '$v_code' WHERE `id` = '$vendor_id'";
    mysqli_query($conn, $update_query);

    // Fetch vendor email
    $email_query = "SELECT `email` FROM `vendors` WHERE `id` = '$vendor_id'";
    $email_result = mysqli_query($conn, $email_query);
    $vendor = mysqli_fetch_assoc($email_result);
    $email = $vendor['email'];

    // Send verification email if status is updated to verified
    if ($new_status === 'Verified') {
        sendMail($email, $v_code);
        echo "<script>alert('Vendor verified and verification email sent.');</script>";
    } else {
        echo "<script>alert('Vendor status updated but not verified.');</script>";
    }

    header("Location: vendor.php");
    exit();
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

function sendMail($email, $v_code) {
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'trendcarts2024@gmail.com';
        $mail->Password   = 'woyy umkj bsgc qinq';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port       = 465;

        $mail->setFrom('trendcarts2024@gmail.com', 'Trend Cart');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'TrendCart - Email Verification';
        $mail->Body    = "Thanks for Registration! Click the link below to verify your email address: <a href='http://localhost/tc1/vendor/verify.php?email=$email&v_code=$v_code'>Verify Email</a>";

        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TrendCart - Manage Vendors</title>
    <style>
        .download-btn {
            float: right;
            margin: 20px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .verify-btn {
            padding: 5px 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
    </style>
</head>
<body>
<div class="wrapper">
    <?php include "admin_sidebar.php"; ?>
    <div class="main p-3">
        <div class="text-center">
            <h1 style="font-size: 30px;">Welcome to Admin</h1>
        </div>

        <div class="container mt-3">
            
            <?php  include "dashboard_min.php"; ?>